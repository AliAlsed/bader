from flask import Flask, render_template , request , flash , session , make_response , redirect , url_for
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.secret_key = 'flasktutorial'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.sqlite3'
db = SQLAlchemy(app)


users = ['ali','suliman','muhammed', 'bader' , 'saleh']
          #  0     1           2         3           4
# sql alchemy relationship one-one one-many many-many
# Table
class students(db.Model):
   __tablename__ = 'students'
   id = db.Column('student_id', db.Integer, primary_key = True)
   name = db.Column(db.String(100))
   city = db.Column(db.String(50))
   addr = db.Column(db.String(200))
   pin = db.Column(db.String(10))
   def __init__(self, name, city, addr, pin):
       self.name = name
       self.city = city
       self.addr = addr
       self.pin = pin

db.create_all()
# localhost:8000/
@app.route('/')
def index():
    return render_template('first.html' , users = users)
# localhost:8000/
@app.route('/about')
def about():
    return render_template('bader.html')
@app.route('/form', methods=['GET','POST'])
def form():

    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        flash( "hello " + name)
        session['name'] = name
        session['age'] = age
        resp = make_response(render_template('post.html', Name = name , Age = age))
        resp.set_cookie('name',name)
        resp.set_cookie('age', age)
        return resp

    if 'name' in session:
        return render_template('post.html', Name = str(session['name']) , Age = str(session['age']))
    else:
        return render_template('form.html')
@app.route('/students-view')
def stdview():
    return render_template('table.html', students=students.query.all())
@app.route('/students', methods=['GET','POST'])
def students_index():
    if request.method == 'POST':
        name = request.form['name']
        city = request.form['city']
        addr = request.form['addr']
        pin = request.form['pin']
        student = students(name, city,addr, pin)
        db.session.add(student)
        db.session.commit()
        flash( "data added successfully ")
        return redirect(url_for('stdview'))
    return render_template('studentform.html')

@app.route('/students/edit/<student_id>', methods=['GET','POST'])
def edit_student(student_id):
    data = db.session.query(students).filter_by(id=student_id).one()
    if request.method == 'POST':
        name = request.form['name']
        city = request.form['city']
        addr = request.form['addr']
        pin = request.form['pin']
        data.name = name
        data.city = city
        data.addr = addr
        data.pin = pin
        db.session.commit()
        return redirect(url_for('stdview'))
    return render_template('edit.html', student = data)
@app.route('/students/delete/<student_id>')
def delete_student(student_id):
    db.session.query(students).filter_by(id=student_id).delete()
    db.session.commit()
    return redirect(url_for('stdview'))
if __name__ == '__main__':
    app.run(port=3000,debug=True)